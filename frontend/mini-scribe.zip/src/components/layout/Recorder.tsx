import React, { useState, useRef } from 'react';
import { Mic, Square, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RecorderProps {
  onTranscriptionComplete?: (text: string) => void;
}

export const Recorder: React.FC<RecorderProps> = ({ onTranscriptionComplete }) => {
  const [status, setStatus] = useState<'idle' | 'recording' | 'transcribing'>('idle');
  const [recordingTime, setRecordingTime] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      const chunks: BlobPart[] = [];
      mediaRecorderRef.current.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      mediaRecorderRef.current.onstop = () => {
        setStatus('transcribing');
        // Simulate transcription
        setTimeout(() => {
          setStatus('idle');
          setRecordingTime(0);
          if (onTranscriptionComplete) {
            onTranscriptionComplete("Audio successfully transcribed.");
          }
        }, 3000);
      };

      mediaRecorderRef.current.start();
      setStatus('recording');
      
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Failed to start recording:', err);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && status === 'recording') {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center gap-2">
      <AnimatePresence mode="wait">
        {status === 'idle' ? (
          <motion.button
            key="start"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            onClick={startRecording}
            className="p-1.5 bg-blue-600 hover:bg-blue-500 rounded-md text-white transition-colors shadow-lg shadow-blue-900/20"
            title="Start Recording"
          >
            <Mic className="w-4 h-4" />
          </motion.button>
        ) : status === 'recording' ? (
          <motion.div
            key="recording"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-md px-2 py-1"
          >
            <div className="flex items-center gap-1.5 mr-1">
              <motion.div
                animate={{ opacity: [1, 0.4, 1] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="w-1.5 h-1.5 rounded-full bg-red-500"
              />
              <span className="text-[10px] font-mono font-bold text-red-500 min-w-[28px]">
                {formatTime(recordingTime)}
              </span>
            </div>
            <button
              onClick={stopRecording}
              className="p-1 bg-red-500 hover:bg-red-400 rounded text-white transition-colors"
              title="Stop Recording"
            >
              <Square className="w-2.5 h-2.5 fill-current" />
            </button>
          </motion.div>
        ) : (
          <motion.div
            key="transcribing"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-md px-2 py-1"
          >
            <Loader2 className="w-3 h-3 text-blue-400 animate-spin" />
            <span className="text-[10px] font-bold text-white/40 uppercase tracking-tight">Transcribing</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
