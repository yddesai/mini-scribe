import { useState, useEffect } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { TranscriptPanel } from './components/transcript/TranscriptPanel';
import { ReportPanel } from './components/report/ReportPanel';
import { MOCK_SOAP, MOCK_TRANSCRIPT_LINES, MOCK_SESSION } from './lib/mockData';
import { List, FileText, Settings, Menu, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

export default function App() {
  const [activeLineIndex, setActiveLineIndex] = useState(13);
  const [isPlaying, setIsPlaying] = useState(false);
  const [reportMode, setReportMode] = useState<'short' | 'long'>('long');
  const [groundingEnabled, setGroundingEnabled] = useState(true);
  const [mobileTab, setMobileTab] = useState<'sessions' | 'transcript' | 'report'>('transcript');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Playback logic
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isPlaying) {
      interval = setInterval(() => {
        setActiveLineIndex((prev) => {
          if (prev >= MOCK_TRANSCRIPT_LINES.length - 1) {
            return 0; // Loop back
          }
          return prev + 1;
        });
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleRefClick = (lineIndex: number) => {
    setIsPlaying(false);
    setActiveLineIndex(lineIndex);
    if (window.innerWidth < 768) {
      setMobileTab('transcript');
    }
  };

  const handleTogglePlay = () => setIsPlaying(!isPlaying);
  const handleReset = () => {
    setIsPlaying(false);
    setActiveLineIndex(0);
  };

  return (
    <div className="flex h-screen w-full bg-[#141414] overflow-hidden font-sans text-white border border-white/10">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block w-[240px] shrink-0">
        <Sidebar activeSessionId={MOCK_SESSION.id} />
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Mobile/Tablet Header */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-[#1a1a1a] border-b border-white/10">
          <button 
            onClick={() => setSidebarOpen(true)}
            className="p-1 hover:bg-white/5 rounded-md"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="text-sm font-bold truncate px-4">{MOCK_SESSION.title}</div>
          <button className="p-1 hover:bg-white/5 rounded-md">
            <Settings className="w-5 h-5 opacity-50" />
          </button>
        </header>

        <div className="flex-1 flex overflow-hidden">
          {/* Transcript Panel: Visible on Desktop, Tablet (Side-by-side with Report), and Mobile (tab specific) */}
          <div className={`
            ${mobileTab === 'transcript' ? 'block' : 'hidden'} 
            md:block md:w-1/2 lg:w-1/2 xl:w-1/2 shrink-0
          `}>
            <TranscriptPanel
              activeLineIndex={activeLineIndex}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              onReset={handleReset}
            />
          </div>

          {/* Report Panel: Visible on Desktop, Tablet (Side-by-side with Transcript), and Mobile (tab specific) */}
          <div className={`
            ${mobileTab === 'report' ? 'block' : 'hidden md:block'} 
            flex-1 min-w-0
          `}>
            <ReportPanel
              report={MOCK_SOAP}
              mode={reportMode}
              onModeChange={setReportMode}
              groundingEnabled={groundingEnabled}
              onGroundingChange={setGroundingEnabled}
              onRefClick={handleRefClick}
            />
          </div>
        </div>

        {/* Mobile Tab Bar (< 768px) */}
        <nav className="md:hidden flex items-center justify-around bg-[#1a1a1a] border-t border-white/10 h-16 pb-safe">
          <button
            onClick={() => setMobileTab('sessions')}
            className={`flex flex-col items-center gap-1 transition-colors ${
              mobileTab === 'sessions' ? 'text-blue-500' : 'text-white/40'
            }`}
          >
            <List className="w-5 h-5" />
            <span className="text-[10px] font-bold">Sessions</span>
          </button>
          <button
            onClick={() => setMobileTab('transcript')}
            className={`flex flex-col items-center gap-1 transition-colors ${
              mobileTab === 'transcript' ? 'text-blue-500' : 'text-white/40'
            }`}
          >
            <div className="relative">
              <FileText className="w-5 h-5" />
              {isPlaying && (
                <span className="absolute -top-1 -right-1 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
              )}
            </div>
            <span className="text-[10px] font-bold">Transcript</span>
          </button>
          <button
            onClick={() => setMobileTab('report')}
            className={`flex flex-col items-center gap-1 transition-colors ${
              mobileTab === 'report' ? 'text-blue-500' : 'text-white/40'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span className="text-[10px] font-bold">Report</span>
          </button>
        </nav>
      </main>

      {/* Mobile Drawer (Sessions) */}
      <AnimatePresence>
        {mobileTab === 'sessions' && window.innerWidth < 768 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 md:hidden"
            onClick={() => setMobileTab('transcript')}
          >
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-[280px] h-full"
              onClick={(e) => e.stopPropagation()}
            >
              <Sidebar activeSessionId={MOCK_SESSION.id} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tablet Slide-over Drawer (Sidebar) */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 hidden md:block lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-[280px] h-full relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={() => setSidebarOpen(false)}
                className="absolute top-4 right-4 z-10 p-1 bg-white/5 rounded-md lg:hidden"
              >
                <X className="w-5 h-5" />
              </button>
              <Sidebar activeSessionId={MOCK_SESSION.id} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
